package com.description;

import java.util.ArrayList;

public interface GetCategories {

	public ArrayList<String> getCategories(String foodPreference);

	public ArrayList<String> getAllergies(String foodPreference);

}
