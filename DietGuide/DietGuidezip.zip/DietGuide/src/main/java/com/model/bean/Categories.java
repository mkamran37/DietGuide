package com.model.bean;

import java.util.List;

@SuppressWarnings("rawtypes")
public class Categories {

	private List categories;
	private List products;
	private String name;

	public List getCategories() {
		return categories;
	}

	public void setCategories(List categories) {
		this.categories = categories;
	}

	public List getProducts() {
		return products;
	}

	public void setProducts(List products) {
		this.products = products;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
