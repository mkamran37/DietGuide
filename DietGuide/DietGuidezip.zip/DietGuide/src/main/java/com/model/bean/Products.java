package com.model.bean;

public class Products {

}
