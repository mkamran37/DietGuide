package com.model;

import com.common.utils.CommonUtils;
import com.controller.Keys;

public class FetchProductsFromAPI {

	private void parseData(String Json) {
		
	}
}
