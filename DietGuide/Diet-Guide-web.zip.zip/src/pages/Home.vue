  <template>
    <layout/>
  </template>

  <script>
    import Layout from '../components/Layout.vue'
  export default {
    name: 'home',
      components: {
    Layout,
  }
  }
  </script>

  <style>
  </style>
