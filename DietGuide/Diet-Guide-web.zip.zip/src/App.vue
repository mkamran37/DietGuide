<template>
  <div id="app"> 
    <home/>
  </div>
</template>

<script>
import Home from './pages/Home.vue'

export default {
  name: 'app',
  components: {
    Home
  }
}
</script>

<style>
</style>
